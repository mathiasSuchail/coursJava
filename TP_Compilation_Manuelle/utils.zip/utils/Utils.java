package utils;

public class Utils{
	public static String convertIntToString(int value){
	return String.valueOf(value);
	}
}
